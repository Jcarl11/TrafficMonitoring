package com.example.cs184p_bc2_20.acitivity2_francisco;

import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.TextureView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Database database;
    EditText USERNAME, PWORD, GENDER;
    Button signInButton;
    String gender;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        database = new Database(this);
        RadioGroup rg = (RadioGroup)findViewById(R.id.rg1);
        USERNAME = (EditText)findViewById(R.id.TEXTFIELD_USERNAME);
        PWORD = (EditText)findViewById(R.id.TEXTFIELD_PASSWORD);
        gender = ((RadioButton)findViewById(rg.getCheckedRadioButtonId())).getText().toString();
        signInButton = (Button) findViewById(R.id.BUTTON_SUBMIT);
        addData();
    }

    public void addData()
    {
        signInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean result = database.insertInfo(USERNAME.getText().toString(), PWORD.getText().toString(),gender);
                if(result = true)
                {
                    Toast.makeText(MainActivity.this,"Success",Toast.LENGTH_LONG).show();
                }
                else
                {
                    Toast.makeText(MainActivity.this,"Insertion Failed",Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}
