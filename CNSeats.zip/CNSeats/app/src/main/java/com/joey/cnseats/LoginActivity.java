package com.joey.cnseats;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
    }

    public void registerClicked(View view)
    {
        Intent registerPage = new Intent(LoginActivity.this,RegisterActivity.class);
        startActivity(registerPage);
    }

    public void loginClicked(View view)
    {
        Intent loginPage = new Intent(LoginActivity.this,HomeScreen.class);
        startActivity(loginPage);
    }
}
